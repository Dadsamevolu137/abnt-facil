from flask import Flask, render_template, request, jsonify, send_file, session
from flask_session import Session
import os, uuid
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Image
from reportlab.lib import colors

from detector import detectar_estrutura, blocos_para_corpo

app = Flask(__name__)
app.secret_key = "troque-essa-chave-por-algo-secreto-antes-de-publicar"
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_FILE_DIR"] = "./flask_session"
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
Session(app)

UPLOAD_FOLDER = "generated_pdfs"
LOGO_FOLDER   = "uploaded_logos"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(LOGO_FOLDER, exist_ok=True)
os.makedirs("flask_session", exist_ok=True)

FREE_LIMIT = 2


def get_guest_count():
    return session.get("guest_pdf_count", 0)

def increment_guest_count():
    session["guest_pdf_count"] = session.get("guest_pdf_count", 0) + 1
    session.modified = True


def get_estilos():
    fonte      = "Times-Roman"
    fonte_bold = "Times-Bold"

    base = ParagraphStyle("base", fontName=fonte, fontSize=12, leading=18,
        textColor=colors.black, alignment=TA_JUSTIFY,
        firstLineIndent=1.25*cm, spaceAfter=0, spaceBefore=0)

    centralizado = ParagraphStyle("centralizado", parent=base,
        alignment=TA_CENTER, firstLineIndent=0)

    centralizado_bold = ParagraphStyle("centralizado_bold", parent=centralizado,
        fontName=fonte_bold)

    secao = ParagraphStyle("secao", parent=base, fontName=fonte_bold,
        alignment=TA_LEFT, firstLineIndent=0,
        spaceBefore=0.5*cm, spaceAfter=0.2*cm)

    subsecao = ParagraphStyle("subsecao", parent=secao, spaceBefore=0.3*cm)

    resumo_titulo = ParagraphStyle("resumo_titulo", parent=centralizado_bold,
        spaceBefore=0, spaceAfter=0.5*cm)

    resumo_texto = ParagraphStyle("resumo_texto", parent=base,
        firstLineIndent=0, alignment=TA_JUSTIFY)

    referencia = ParagraphStyle("referencia", parent=base,
        firstLineIndent=0, alignment=TA_JUSTIFY, spaceAfter=0.2*cm)

    return {
        "base": base, "centralizado": centralizado,
        "centralizado_bold": centralizado_bold,
        "secao": secao, "subsecao": subsecao,
        "resumo_titulo": resumo_titulo,
        "resumo_texto": resumo_texto,
        "referencia": referencia,
    }


def gerar_pdf_abnt(data, filepath, logo_path=None):
    titulo        = data.get("titulo", "").strip()
    autores_raw   = data.get("autor", "").strip()
    instituicao   = data.get("instituicao", "").strip()
    campus        = data.get("campus", "").strip()
    curso         = data.get("curso", "").strip()
    cidade        = data.get("cidade", "").strip()
    ano           = data.get("ano", str(datetime.now().year)).strip()
    mes           = data.get("mes", "").strip()
    orientador    = data.get("orientador", "").strip()
    resumo        = data.get("resumo", "").strip()
    palavras_chave= data.get("palavras_chave", "").strip()
    corpo         = data.get("corpo", "").strip()
    referencias   = data.get("referencias", "").strip()
    tipo_trabalho = data.get("tipo_trabalho", "Trabalho Academico").strip()
    turma         = data.get("turma", "").strip()
    disciplina    = data.get("disciplina", "").strip()

    autores    = [a.strip() for a in autores_raw.split(",") if a.strip()]
    autores_str = ", ".join(a.upper() for a in autores)
    data_extenso = f"{mes} de {ano}" if mes else ano

    doc = SimpleDocTemplate(filepath, pagesize=A4,
        topMargin=3*cm, bottomMargin=2*cm,
        leftMargin=3*cm, rightMargin=2*cm)

    estilos      = get_estilos()
    story        = []
    largura_util = A4[0] - 3*cm - 2*cm
    altura_util  = A4[1] - 3*cm - 2*cm

    def add_logo():
        if logo_path and os.path.exists(logo_path):
            try:
                img = Image(logo_path, width=3.5*cm, height=3.5*cm, kind="proportional")
                img.hAlign = "CENTER"
                story.append(img)
                story.append(Spacer(1, 0.3*cm))
            except Exception:
                pass

    # ===== CAPA =====
    add_logo()
    if campus:
        story.append(Paragraph(f"<i>Campus</i> {campus}", estilos["centralizado"]))
    elif instituicao:
        story.append(Paragraph(instituicao.upper(), estilos["centralizado_bold"]))

    story.append(Spacer(1, altura_util * 0.20))
    story.append(Paragraph(autores_str, estilos["centralizado_bold"]))
    story.append(Spacer(1, 1.5*cm))
    story.append(Paragraph(titulo, estilos["centralizado"]))
    story.append(Spacer(1, altura_util * 0.20))

    if cidade:
        story.append(Paragraph(cidade, estilos["centralizado"]))
    story.append(Paragraph(data_extenso, estilos["centralizado"]))
    story.append(PageBreak())

    # ===== FOLHA DE ROSTO =====
    add_logo()
    if campus:
        story.append(Paragraph(f"<i>Campus</i> {campus}", estilos["centralizado"]))

    story.append(Spacer(1, 1*cm))
    story.append(Paragraph(autores_str, estilos["centralizado_bold"]))
    story.append(Spacer(1, 1.5*cm))
    story.append(Paragraph(titulo, estilos["centralizado"]))
    story.append(Spacer(1, 2*cm))

    partes_nota = [tipo_trabalho + " apresentado"]
    if disciplina: partes_nota.append(f"à disciplina {disciplina},")
    if turma:      partes_nota.append(f"Turma {turma},")
    if curso:      partes_nota.append(f"do curso de {curso},")
    if instituicao:partes_nota.append(f"do {instituicao}.")
    else:
        if partes_nota: partes_nota[-1] = partes_nota[-1].rstrip(",") + "."

    nota_html = " ".join(partes_nota)
    if orientador:
        nota_html += f"<br/>Prof.: {orientador}"

    nota_estilo = ParagraphStyle("nota_direita", parent=estilos["base"],
        fontSize=12, leading=18, firstLineIndent=0,
        alignment=TA_JUSTIFY, leftIndent=largura_util * 0.45)

    story.append(Paragraph(nota_html, nota_estilo))
    story.append(Spacer(1, 2.5*cm))
    if cidade:
        story.append(Paragraph(cidade, estilos["centralizado"]))
    story.append(Paragraph(data_extenso, estilos["centralizado"]))
    story.append(PageBreak())

    # ===== RESUMO =====
    if resumo:
        story.append(Paragraph("RESUMO", estilos["resumo_titulo"]))
        story.append(Paragraph(resumo, estilos["resumo_texto"]))
        if palavras_chave:
            story.append(Spacer(1, 0.5*cm))
            story.append(Paragraph(
                f"<b>Palavras-chave:</b> {palavras_chave}.",
                estilos["resumo_texto"]))
        story.append(PageBreak())

    # ===== CORPO =====
    if corpo:
        for bloco in corpo.split("\n\n"):
            bloco = bloco.strip()
            if not bloco: continue
            if bloco.startswith("# "):
                story.append(Paragraph(bloco[2:].strip().upper(), estilos["secao"]))
            elif bloco.startswith("## "):
                story.append(Paragraph(bloco[3:].strip(), estilos["subsecao"]))
            elif bloco.startswith("### "):
                story.append(Paragraph(bloco[4:].strip(), estilos["subsecao"]))
            else:
                story.append(Paragraph(" ".join(bloco.split("\n")), estilos["base"]))
                story.append(Spacer(1, 6))

    # ===== REFERÊNCIAS =====
    if referencias:
        story.append(PageBreak())
        story.append(Paragraph("REFERÊNCIAS BIBLIOGRÁFICAS", estilos["secao"]))
        story.append(Spacer(1, 0.5*cm))
        for ref in referencias.strip().split("\n"):
            ref = ref.strip()
            if ref:
                story.append(Paragraph(ref, estilos["referencia"]))

    doc.build(story)


# ==================== ROTAS ====================

@app.route("/")
def index():
    return render_template("index.html",
        guest_count=get_guest_count(),
        free_limit=FREE_LIMIT,
        ano=datetime.now().year)


@app.route("/detectar-estrutura", methods=["POST"])
def detectar():
    """Recebe texto puro e devolve blocos detectados para o frontend confirmar."""
    data = request.get_json()
    if not data or not data.get("texto"):
        return jsonify({"erro": "Texto vazio"}), 400

    texto = data["texto"]
    blocos = detectar_estrutura(texto)

    # Separa referências automaticamente se detectadas no final
    refs_blocos = []
    corpo_blocos = []
    em_refs = False
    for b in blocos:
        txt_norm = b["texto"].lower().strip().lstrip("#").strip()
        if any(txt_norm.startswith(r) for r in ["referência", "referencia", "bibliografia"]):
            em_refs = True
        if em_refs and b["tipo"] == "paragrafo":
            refs_blocos.append(b)
        else:
            corpo_blocos.append(b)

    return jsonify({
        "blocos": corpo_blocos,
        "referencias": refs_blocos,
        "total": len(blocos)
    })


@app.route("/upload-logo", methods=["POST"])
def upload_logo():
    if "logo" not in request.files:
        return jsonify({"erro": "Nenhum arquivo enviado"}), 400
    file = request.files["logo"]
    ext  = os.path.splitext(file.filename)[1].lower()
    if ext not in [".png", ".jpg", ".jpeg"]:
        return jsonify({"erro": "Apenas PNG ou JPG são aceitos"}), 400
    logo_id  = uuid.uuid4().hex[:10]
    filename = f"logo_{logo_id}{ext}"
    filepath = os.path.join(LOGO_FOLDER, filename)
    file.save(filepath)
    session["logo_file"] = filename
    session.modified = True
    return jsonify({"sucesso": True})


@app.route("/remover-logo", methods=["POST"])
def remover_logo():
    logo_file = session.get("logo_file")
    if logo_file:
        path = os.path.join(LOGO_FOLDER, logo_file)
        if os.path.exists(path): os.remove(path)
        session.pop("logo_file", None)
        session.modified = True
    return jsonify({"sucesso": True})


@app.route("/gerar-pdf", methods=["POST"])
def gerar_pdf():
    if get_guest_count() >= FREE_LIMIT:
        return jsonify({"erro": "limite_atingido",
            "count": get_guest_count(), "limite": FREE_LIMIT}), 403

    data = request.get_json()
    if not data or (not data.get("titulo") and not data.get("corpo")):
        return jsonify({"erro": "Preencha pelo menos o título ou o corpo."}), 400

    try:
        filename  = f"abnt_{uuid.uuid4().hex[:8]}.pdf"
        filepath  = os.path.join(UPLOAD_FOLDER, filename)
        logo_path = None
        logo_file = session.get("logo_file")
        if logo_file:
            candidate = os.path.join(LOGO_FOLDER, logo_file)
            if os.path.exists(candidate): logo_path = candidate

        gerar_pdf_abnt(data, filepath, logo_path=logo_path)
        increment_guest_count()
        new_count = get_guest_count()

        return jsonify({"sucesso": True, "arquivo": filename,
            "count": new_count, "limite": FREE_LIMIT,
            "restantes": max(0, FREE_LIMIT - new_count)})

    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({"erro": f"Erro ao gerar PDF: {str(e)}"}), 500


@app.route("/download/<filename>")
def download(filename):
    if not filename.endswith(".pdf") or "/" in filename or ".." in filename:
        return "Inválido", 400
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    if not os.path.exists(filepath): return "Não encontrado", 404
    return send_file(filepath, as_attachment=True, download_name="trabalho_abnt.pdf")


@app.route("/status")
def status():
    count = get_guest_count()
    return jsonify({"count": count, "limite": FREE_LIMIT,
        "restantes": max(0, FREE_LIMIT - count)})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
