let etapaAtual = 1;
const TOTAL_ETAPAS = 4;
let blocosConfirmados = [];

// ===== NAVEGAÇÃO =====
function proximaEtapa(num) {
  if (num > etapaAtual && !validarEtapa(etapaAtual)) return;
  document.getElementById(`etapa-${etapaAtual}`).classList.add("oculto");
  document.getElementById(`etapa-${num}`).classList.remove("oculto");
  for (let i = 1; i <= TOTAL_ETAPAS; i++) {
    const step = document.querySelector(`.progress-step[data-step="${i}"]`);
    if (!step) continue;
    step.classList.remove("active", "concluido");
    if (i < num) step.classList.add("concluido");
    else if (i === num) step.classList.add("active");
  }
  etapaAtual = num;
  window.scrollTo({ top: 0, behavior: "smooth" });
  atualizarContador();
}

// ===== VALIDAÇÃO =====
function validarEtapa(num) {
  if (num === 1) {
    const titulo = document.getElementById("titulo").value.trim();
    const autor  = document.getElementById("autor").value.trim();
    if (!titulo) { mostrarToast("Preencha o título do trabalho", "erro"); focar("titulo"); return false; }
    if (!autor)  { mostrarToast("Preencha pelo menos um autor", "erro"); focar("autor"); return false; }
  }
  if (num === 2) {
    const texto = document.getElementById("texto_bruto").value.trim();
    if (!texto) { mostrarToast("Cole o texto do trabalho", "erro"); focar("texto_bruto"); return false; }
  }
  return true;
}

function focar(id) {
  const el = document.getElementById(id);
  el.focus();
  el.scrollIntoView({ behavior: "smooth", block: "center" });
}

// ===== ANALISAR TEXTO =====
async function analisarTexto() {
  if (!validarEtapa(2)) return;

  const btn = document.querySelector('#etapa-2 .btn-next');
  btn.textContent = "Analisando...";
  btn.disabled = true;

  const texto = document.getElementById("texto_bruto").value.trim();

  try {
    const resp = await fetch("/detectar-estrutura", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ texto })
    });
    const data = await resp.json();

    if (!resp.ok || data.erro) {
      mostrarToast(data.erro || "Erro ao analisar texto", "erro");
      return;
    }

    blocosConfirmados = data.blocos;
    renderizarEstrutura(data.blocos);

    // Preenche referências detectadas automaticamente
    if (data.referencias && data.referencias.length > 0) {
      const refsTexto = data.referencias.map(b => b.texto).join("\n");
      document.getElementById("referencias").value = refsTexto;
    }

    proximaEtapa(3);

  } catch (e) {
    mostrarToast("Erro de conexão ao analisar texto", "erro");
  } finally {
    btn.textContent = "Analisar estrutura →";
    btn.disabled = false;
  }
}

// ===== RENDERIZAR ESTRUTURA =====
const TIPO_LABELS = { secao: "Seção", subsecao: "Subseção", paragrafo: "Parágrafo" };
const TIPO_CORES  = { secao: "b-purple", subsecao: "b-teal", paragrafo: "b-gray" };

function renderizarEstrutura(blocos) {
  const container = document.getElementById("estrutura-preview");
  if (!blocos || blocos.length === 0) {
    container.innerHTML = '<p style="color:var(--text-2);text-align:center;padding:2rem;">Nenhuma estrutura detectada. Volte e verifique o texto.</p>';
    return;
  }

  container.innerHTML = blocos.map((b, i) => `
    <div class="bloco-item" id="bloco-${i}">
      <div class="bloco-tipo">
        <select class="bloco-select" onchange="alterarTipo(${i}, this.value)">
          <option value="secao"    ${b.tipo==='secao'    ? 'selected':''}>Seção</option>
          <option value="subsecao" ${b.tipo==='subsecao' ? 'selected':''}>Subseção</option>
          <option value="paragrafo"${b.tipo==='paragrafo'? 'selected':''}>Parágrafo</option>
        </select>
        <span class="bloco-badge badge-${b.tipo}">${TIPO_LABELS[b.tipo]||b.tipo}</span>
      </div>
      <div class="bloco-texto" id="bloco-texto-${i}">${escapar(b.texto)}</div>
    </div>
  `).join('');
}

function alterarTipo(idx, novoTipo) {
  blocosConfirmados[idx].tipo = novoTipo;
  const badge = document.querySelector(`#bloco-${idx} .bloco-badge`);
  badge.textContent = TIPO_LABELS[novoTipo] || novoTipo;
  badge.className = `bloco-badge badge-${novoTipo}`;
}

function escapar(txt) {
  return txt.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ===== MONTAR CORPO A PARTIR DOS BLOCOS CONFIRMADOS =====
function blocosParaCorpo(blocos) {
  return blocos.map(b => {
    if (b.tipo === 'secao')    return `# ${b.texto}`;
    if (b.tipo === 'subsecao') return `## ${b.texto}`;
    return b.texto;
  }).join('\n\n');
}

// ===== UPLOAD LOGO =====
async function uploadLogo(input) {
  const file = input.files[0];
  if (!file) return;
  const formData = new FormData();
  formData.append("logo", file);
  try {
    const resp = await fetch("/upload-logo", { method: "POST", body: formData });
    const data = await resp.json();
    if (data.sucesso) {
      const reader = new FileReader();
      reader.onload = (e) => {
        document.getElementById("logo-img").src = e.target.result;
        document.getElementById("logo-placeholder").classList.add("oculto");
        document.getElementById("logo-preview").classList.remove("oculto");
      };
      reader.readAsDataURL(file);
      mostrarToast("Logo enviado!", "sucesso");
    } else {
      mostrarToast(data.erro || "Erro ao enviar logo", "erro");
    }
  } catch { mostrarToast("Erro de conexão", "erro"); }
  input.value = "";
}

async function removerLogo(e) {
  e.stopPropagation();
  try { await fetch("/remover-logo", { method: "POST" }); } catch {}
  document.getElementById("logo-placeholder").classList.remove("oculto");
  document.getElementById("logo-preview").classList.add("oculto");
  document.getElementById("logo-img").src = "";
  mostrarToast("Logo removido", "");
}

// ===== GERAR PDF =====
async function gerarPDF() {
  const btnTexto   = document.getElementById("btn-texto");
  const btnLoading = document.getElementById("btn-loading");
  const btnGerar   = document.getElementById("btn-gerar");
  btnTexto.classList.add("oculto");
  btnLoading.classList.remove("oculto");
  btnGerar.disabled = true;

  const corpo = blocosParaCorpo(blocosConfirmados);

  const dados = {
    titulo:         document.getElementById("titulo").value.trim(),
    autor:          document.getElementById("autor").value.trim(),
    instituicao:    document.getElementById("instituicao").value.trim(),
    campus:         document.getElementById("campus").value.trim(),
    curso:          document.getElementById("curso").value.trim(),
    disciplina:     document.getElementById("disciplina").value.trim(),
    turma:          document.getElementById("turma").value.trim(),
    orientador:     document.getElementById("orientador").value.trim(),
    tipo_trabalho:  document.getElementById("tipo_trabalho").value,
    cidade:         document.getElementById("cidade").value.trim(),
    mes:            document.getElementById("mes").value.trim(),
    ano:            document.getElementById("ano").value.trim(),
    resumo:         document.getElementById("resumo").value.trim(),
    palavras_chave: document.getElementById("palavras_chave").value.trim(),
    corpo:          corpo,
    referencias:    document.getElementById("referencias").value.trim(),
  };

  try {
    const resp = await fetch("/gerar-pdf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dados),
    });
    const data = await resp.json();

    if (resp.status === 403 && data.erro === "limite_atingido") { abrirModalLimite(); return; }
    if (!resp.ok || data.erro) { mostrarToast(data.erro || "Erro ao gerar PDF.", "erro"); return; }

    contadorAtual = data.restantes;
    atualizarContador();
    document.getElementById("link-download").href = `/download/${data.arquivo}`;
    document.getElementById("resultado").classList.remove("oculto");
    document.getElementById("resultado").scrollIntoView({ behavior: "smooth", block: "center" });
    mostrarToast("PDF gerado com sucesso!", "sucesso");

  } catch { mostrarToast("Erro de conexão.", "erro"); }
  finally {
    btnTexto.classList.remove("oculto");
    btnLoading.classList.add("oculto");
    btnGerar.disabled = false;
  }
}

function novoTrabalho() {
  document.getElementById("resultado").classList.add("oculto");
  document.getElementById("form-abnt").reset();
  document.getElementById("logo-placeholder").classList.remove("oculto");
  document.getElementById("logo-preview").classList.add("oculto");
  blocosConfirmados = [];
  proximaEtapa(1);
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// ===== CONTADOR =====
function atualizarContador() {
  const usoNum = document.getElementById("uso-num");
  if (usoNum) usoNum.textContent = contadorAtual;
  const circuloNum  = document.getElementById("contador-num");
  const circuloFill = document.getElementById("circle-fill");
  if (circuloNum)  circuloNum.textContent = contadorAtual;
  if (circuloFill) {
    circuloFill.style.strokeDashoffset = 113 * (1 - Math.max(0, contadorAtual / FREE_LIMIT));
    circuloFill.style.stroke = contadorAtual === 0 ? "#f87171" : contadorAtual === 1 ? "#facc15" : "";
  }
}

// ===== MODAIS =====
function abrirModalConta()   { document.getElementById("modal-conta").classList.remove("oculto"); }
function fecharModalConta()  { document.getElementById("modal-conta").classList.add("oculto"); }
function abrirModalLimite()  { document.getElementById("modal-limite").classList.remove("oculto"); }
function fecharModalLimite() { document.getElementById("modal-limite").classList.add("oculto"); }
document.addEventListener("click", e => {
  if (e.target.classList.contains("modal-overlay")) { fecharModalConta(); fecharModalLimite(); }
});

// ===== TOAST =====
let toastTimer = null;
function mostrarToast(msg, tipo = "") {
  let toast = document.getElementById("toast-global");
  if (!toast) { toast = document.createElement("div"); toast.id = "toast-global"; toast.className = "toast"; document.body.appendChild(toast); }
  toast.textContent = msg;
  toast.className = `toast ${tipo}`;
  setTimeout(() => toast.classList.add("show"), 10);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
}

document.addEventListener("DOMContentLoaded", () => {
  atualizarContador();
  const anoInput = document.getElementById("ano");
  if (!anoInput.value) anoInput.value = new Date().getFullYear();
});
